# SensorFusion-HAR Report — LaTeX source

Bennett University HDP-template version of the report.

## Files

- `main.tex` — the report source
- `references.bib` — bibliography database
- `Logo_1.jpeg` — Bennett University logo (from the template)
- `architecture.png`, `training_curves.png`, `perclass_f1.png`,
  `confusion_matrix.png`, `v1_vs_final.png`, `capability_radar.png` —
  figures embedded in the report
- `main.pdf` — pre-built PDF (20 pages, US Letter, 1.5 line spacing)

## Build

Standard three-pass with bibtex:

```bash
pdflatex main.tex
bibtex   main
pdflatex main.tex
pdflatex main.tex
```

Or in Overleaf, just drop the whole folder in and hit Recompile.

## Required LaTeX packages

All standard. The non-trivial ones:
- `newtx` (Times-like serif fonts) — needs the `tex-gyre` font support
- `geometry`, `hyperref`, `cite`, `placeins`, `float`, `tocbibind`,
  `parskip`, `caption`

On Debian/Ubuntu these come from `texlive-fonts-extra`,
`texlive-latex-extra`, `texlive-plain-generic`, `tex-gyre`.
