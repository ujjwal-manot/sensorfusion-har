# Fixes applied — HIL Implementation

Same root-cause fixes as the real-life repo for the shared files
(`hil_server.py`, `train_esp32_v2_expanded_local.py`, `generate_cert.py`),
plus HIL-specific issues. See `../RealLife_Implementation/BUGFIXES.md` for
detailed descriptions of each bug.

## Round 1 — surface fixes

1. `hil_server.py` — full rewrite. `args.baud_rate` instead of `args.baud`,
   wrong JSON key layout, brittle relative paths, mixing `websockets`
   library with FastAPI methods.
2. `train_esp32_v2_expanded_local.py` — duplicate keys in `PAMAP2_TO_MERGED`.
3. `server.py` — wrong shape `(1, T, C)` in `normalize()` call inside HIL
   handler.
4. `test_onnx_model.py` — wrong path (`parent.parent/exports/esp32_v2/`)
   and a misleading "probability" print that was actually showing a raw
   logit. Now searches multiple plausible locations and applies softmax.
5. `generate_cert.py` — `datetime.utcnow()` deprecated.

## Round 2 — deeper QA pass (matches RealLife)

6. `train_esp32_v2_expanded_local.py` — `NUM_CLASSES = 7` mismatched the
   deployed 11-class system. Fixed to 11 classes with the canonical label
   order matching `esp32_v2_useful11_config.h`.
7. `train_esp32_v2_expanded_local.py` — every dataset-to-merged mapping
   was broken (wrong source-label indexing, targeting deleted 7-class
   layout). All three mappings rewritten; all 11 merged classes now
   reachable from at least one source.
8. `train_esp32_v2_expanded_local.py` — `sys.path` insertion now walks
   upward looking for a sibling `model/` package, so the script works
   whether HIL_Implementation is dropped into a parent project (per the
   README) or run standalone.
9. `server.py` — wrong package path `final_esp32_v2_useful11_package`
   (folder doesn't exist) replaced with `training/`.

## Verified working after Round 2

- Every Python file parses without syntax errors.
- `hil_server.py` accepts `--help` cleanly.
- `server.py` imports cleanly.
- `test_onnx_model.py` actually loads and runs the bundled ONNX model
  end-to-end and prints a softmax-normalised confidence.
- `generate_cert.py` writes a valid certificate.
- `train_esp32_v2_expanded_local.py` accepts `--help` cleanly when
  HIL_Implementation/ sits next to a `model/` package.

## Note on the bundled ONNX file

`exports/sensorfusion_esp32_v2_pocket_final.onnx` was exported from the
**old 7-class** training run (you can confirm: its output shape is
`(1, 7)`). Running it through `test_onnx_model.py` now succeeds, but the
classes do NOT match the 11-class label set used by the dashboards, the
ESP32 firmware, and the rewritten training script. After re-training with
the corrected `train_esp32_v2_expanded_local.py`, re-run the ONNX export
step to produce a fresh `(1, 11)` model that matches the deployment
surface.
