"""
Test the ONNX export with onnxruntime (works on Python 3.14).

Validates the model loads, accepts the expected (1, 50, 6) input, and
produces an 11-element output. For ESP32 deployment you still need to
generate the TFLite INT8 model via Colab (Python 3.10/3.11) since
onnx2tf doesn't yet build cleanly on 3.14.

Fixes vs the original:
  * Path was `Path(__file__).parent.parent / "exports" / "esp32_v2"`,
    which assumed this file lived two levels deep inside a `training/`
    folder. The actual file lives next to ./exports/, so the path now
    just walks one level down with a fallback.
  * Output is logits, not probabilities — np.max(prediction[0]) was
    being printed as a "probability" but could exceed 1. Softmax is
    applied before reporting confidence.
"""
from __future__ import annotations

import numpy as np
import onnxruntime as ort
from pathlib import Path

HERE = Path(__file__).resolve().parent

# Try a few likely locations so the script keeps working whether the user
# runs it from the repo root or from inside HIL_Implementation/.
candidates = [
    HERE / "exports" / "sensorfusion_esp32_v2_pocket_final.onnx",
    HERE / "exports" / "sensorfusion_esp32_v2_useful11_final.onnx",
    HERE / "exports" / "sensorfusion_esp32_v2_useful11.onnx",
    HERE / "exports" / "esp32_v2" / "sensorfusion_esp32_v2_pocket_final.onnx",
    HERE.parent / "exports" / "esp32_v2" / "sensorfusion_esp32_v2_pocket_final.onnx",
]
onnx_path = next((p for p in candidates if p.exists()), None)

if onnx_path is None:
    print("Error: no ONNX model found in any of:")
    for p in candidates:
        print(f"  - {p}")
    print("\nAvailable .onnx files near this script:")
    for f in sorted((HERE / "exports").rglob("*.onnx")):
        print(f"  - {f}")
    raise SystemExit(1)

print(f"Loading ONNX model: {onnx_path}")
session = ort.InferenceSession(str(onnx_path))

input_meta = session.get_inputs()[0]
output_meta = session.get_outputs()[0]
print("\nModel info:")
print(f"  input  : {input_meta.name}, shape={input_meta.shape}")
print(f"  output : {output_meta.name}, shape={output_meta.shape}")

rng = np.random.default_rng(0)
test_input = rng.standard_normal((1, 50, 6)).astype(np.float32)
logits = session.run([output_meta.name], {input_meta.name: test_input})[0]

# Softmax for a real probability — the previous code printed the raw max
# logit and called it a probability, which is misleading.
shifted = logits[0] - logits[0].max()
probs = np.exp(shifted) / np.exp(shifted).sum()
predicted_class = int(np.argmax(probs))
confidence = float(probs[predicted_class])

print("\nInference test:")
print(f"  input  shape   : {test_input.shape}")
print(f"  output shape   : {logits.shape}")
print(f"  predicted class: {predicted_class}")
print(f"  confidence     : {confidence:.4f}")

print("\nONNX model works correctly.")
print("Note: for ESP32 deployment, generate the TFLite INT8 model via Colab.")
print("See HIL_Implementation/generate_tflite_model.ipynb for the recipe.")
